let scene, camera, renderer, score = 0, hp = 100;
let targets = [], bullets = [];
const audioCtx = new (window.AudioContext || window.webkitAudioContext)();

// --- ЗВУКИ ---
function playShootSound() {
  const osc = audioCtx.createOscillator();
  const gain = audioCtx.createGain();
  osc.type = 'triangle';
  osc.frequency.setValueAtTime(200, audioCtx.currentTime);
  osc.frequency.exponentialRampToValueAtTime(20, audioCtx.currentTime + 0.1);
  gain.gain.setValueAtTime(0.1, audioCtx.currentTime);
  gain.gain.linearRampToValueAtTime(0, audioCtx.currentTime + 0.1);
  osc.connect(gain); gain.connect(audioCtx.destination);
  osc.start(); osc.stop(audioCtx.currentTime + 0.1);
}

function initDroneSound(drone) {
  const osc = audioCtx.createOscillator();
  const gain = audioCtx.createGain();
  osc.type = 'sawtooth'; // Характерный звук двигателя
  osc.frequency.value = 70 + Math.random() * 20;
  gain.gain.value = 0; 
  osc.connect(gain); gain.connect(audioCtx.destination);
  osc.start();
  drone.userData.audio = { osc, gain };
}

function init() {
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x87CEEB);
  camera = new THREE.PerspectiveCamera(75, window.innerWidth/window.innerHeight, 0.1, 3000);
  camera.rotation.order = 'YXZ';
  renderer = new THREE.WebGLRenderer({ antialias: true });
  renderer.setSize(window.innerWidth, window.innerHeight);
  document.body.appendChild(renderer.domElement);

  const sun = new THREE.DirectionalLight(0xffffff, 1.2);
  sun.position.set(100, 300, 100); scene.add(sun);
  scene.add(new THREE.AmbientLight(0xffffff, 0.4));

  // ПОЛЕ
  const field = new THREE.Mesh(
    new THREE.PlaneGeometry(5000, 5000),
    new THREE.MeshStandardMaterial({ color: 0x354a21 })
  );
  field.rotation.x = -Math.PI/2; scene.add(field);

  // ГОРОД С ОКНАМИ
  for(let i=0; i < 120; i++) {
    let h = 40 + Math.random() * 80;
    let b = new THREE.Mesh(
      new THREE.BoxGeometry(15, h, 15),
      new THREE.MeshStandardMaterial({ color: 0x444444 })
    );
    b.position.set(Math.random()*1000-500, h/2, -1000 - Math.random()*500);
    scene.add(b);
  }

  camera.position.set(0, 2, 300);
}

function createShahed() {
  const group = new THREE.Group();
  const mat = new THREE.MeshStandardMaterial({ color: 0x222222 });
  
  // Крыло-дельта (увеличено)
  const shape = new THREE.Shape();
  shape.moveTo(0, 3.5); shape.lineTo(-4, -2); shape.lineTo(4, -2); shape.lineTo(0, 3.5);
  const wing = new THREE.Mesh(new THREE.ExtrudeGeometry(shape, {depth: 0.3, bevelEnabled: false}), mat);
  wing.rotation.x = Math.PI/2; group.add(wing);

  // Нос и фюзеляж
  const nose = new THREE.Mesh(new THREE.CylinderGeometry(0.4, 0.4, 6), mat);
  nose.rotation.x = Math.PI/2; nose.position.z = 1.5; group.add(nose);
  
  return group;
}

function spawnDrone() {
  if (Math.random() < 0.015 && hp > 0) {
    const drone = createShahed();
    drone.position.set(Math.random()*400-200, 40 + Math.random()*30, 800);
    drone.lookAt(0, 40, -2000);
    scene.add(drone);
    targets.push(drone);
    initDroneSound(drone);
  }
}

document.addEventListener('mousedown', () => {
  if (audioCtx.state === 'suspended') audioCtx.resume();
  if (document.pointerLockElement !== document.body) {
    document.body.requestPointerLock();
  } else if (hp > 0) {
    playShootSound();
    const b = new THREE.Mesh(new THREE.SphereGeometry(0.6), new THREE.MeshBasicMaterial({color: 0xffaa00}));
    b.position.copy(camera.position);
    let dir = new THREE.Vector3(0, 0, -1).applyQuaternion(camera.quaternion);
    b.userData.velocity = dir.multiplyScalar(15);
    bullets.push(b); scene.add(b);
  }
});

document.addEventListener('mousemove', (e) => {
  if (document.pointerLockElement === document.body) {
    camera.rotation.y -= e.movementX * 0.002;
    camera.rotation.x -= e.movementY * 0.002;
  }
});

function animate() {
  requestAnimationFrame(animate);
  if (hp > 0) {
    spawnDrone();
    
    // Радар
    const dots = document.getElementById('radar-dots');
    dots.innerHTML = '';
    
    // Пули (БЕЗ автонаводки)
    bullets.forEach((b, i) => {
      b.position.add(b.userData.velocity);
      if(b.position.z < -1500) { scene.remove(b); bullets.splice(i, 1); }
    });

    // Дроны (МЕДЛЕННО и со ЗВУКОМ)
    targets.forEach((t, i) => {
      t.position.z -= 1.4;

      // Радар точка
      const dot = document.createElement('div');
      dot.className = 'dot';
      dot.style.left = (t.position.x/400*50 + 50) + '%';
      dot.style.top = (t.position.z/800*50 + 50) + '%';
      dots.appendChild(dot);

      // Звук жужжания
      const dist = camera.position.distanceTo(t.position);
      t.userData.audio.gain.gain.value = Math.max(0, 0.2 - dist/1500);
      t.userData.audio.osc.frequency.value = 60 + (1000/dist);

      // Попадание
      bullets.forEach((b, bi) => {
        if(t.position.distanceTo(b.position) < 12) {
          t.userData.audio.osc.stop();
          scene.remove(t); scene.remove(b);
          targets.splice(i, 1); bullets.splice(bi, 1);
          score++; document.getElementById('score').innerText = score;
        }
      });

      if(t.position.z < -900) {
        t.userData.audio.osc.stop();
        scene.remove(t); targets.splice(i, 1);
        hp -= 10; document.getElementById('hp').innerText = Math.max(0, hp);
      }
    });
  }
  renderer.render(scene, camera);
}

init(); animate();